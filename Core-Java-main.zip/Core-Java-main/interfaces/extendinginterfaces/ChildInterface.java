//child interface inherits from InterfaceOne//
package interfaces.extendinginterfaces;

public interface ChildInterface extends InterfaceOne {
	void show();
}
