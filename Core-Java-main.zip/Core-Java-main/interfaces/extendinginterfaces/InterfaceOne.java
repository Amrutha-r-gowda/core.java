//InterfaceOne declaration
package interfaces.extendinginterfaces;

interface InterfaceOne{  
  void print();  
}  

