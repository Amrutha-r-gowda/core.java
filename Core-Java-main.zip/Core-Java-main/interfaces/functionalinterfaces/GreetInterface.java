//Program to demonstrate FunctionalInterface - Greet Interface
package interfaces.functionalinterfaces;

@FunctionalInterface
public interface GreetInterface {
	public String greet();
}
