//Program to demonstrate Marker Interface
package interfaces.markerinterfaces;

public interface Registrable {

}
